# Git Practice Assignment

## Student Details
- **Name:** Siva Chetan
- **Roll Number:** BT25CSE206
- **Section:** CSE C

## Assignment Description
This assignment demonstrates Git and GitHub for source code management and version control, including programming exercises, version history, and collaboration workflows.

## Exercises
1. Exercise 01: Addition of Two Numbers
2. Exercise 02: Even or Odd
3. Exercise 03: Largest of Two Numbers

## Repository Structure
- `exercise-01/`: Addition program, sample input, and output
- `exercise-02/`: Even-or-odd program, sample input, and output
- `exercise-03/`: Largest-of-two program, sample input, and output
- `git-commands.md`: Git commands and notes

## Compile and Run
Open a terminal in the exercise folder.

```bash
gcc main.c -o main
./main
```

Enter the input shown in that exercise's `input.txt`. Expected results are in `output.txt`.

## GitHub Issues and Pull Requests
Add the links to **your own** issues and pull requests here after creating them:
- Exercise 01 issue: _add your issue URL_
- Exercise 02 issue: _add your issue URL_
- Exercise 03 issue: _add your issue URL_
- Documentation pull request: _add your pull request URL_

## Git Practice Record
See [`git-commands.md`](git-commands.md) for a practice command record. Record the commands you actually run and describe a merge conflict only if you encounter and resolve one.

## Conclusion
This repository records the programming exercises and practice with Git and GitHub workflows.
