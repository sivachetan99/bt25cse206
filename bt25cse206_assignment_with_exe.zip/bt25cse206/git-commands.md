# Git Practice Record

Use this as a guide. Update the record to reflect the commands you actually ran.

| Command | Purpose |
|---|---|
| `git init` | Initialize a local repository (only if starting locally) |
| `git status` | Check changed and untracked files |
| `git add .` | Stage files |
| `git commit -m "Add exercise programs"` | Save a snapshot with a message |
| `git branch` | List branches |
| `git switch -c feature/docs` | Create and switch to a branch |
| `git push -u origin feature/docs` | Publish the branch |
| `git pull` | Fetch and integrate remote updates |

## Merge Conflict Record
Do not claim a conflict happened unless you encountered one. If one occurs, record:
- Files that conflicted:
- Why the edits conflicted:
- How it was resolved:
- Commit that completed the resolution:
